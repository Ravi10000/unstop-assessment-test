function MyAssessmentsPage() {
  return (
    <div>
      <h1>My Assessments</h1>
    </div>
  );
}

export default MyAssessmentsPage;
