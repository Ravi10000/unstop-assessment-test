function UnstopAssessmentsPage() {
  return (
    <div>
      <h1>Unstop Assessments</h1>
    </div>
  );
}

export default UnstopAssessmentsPage;
